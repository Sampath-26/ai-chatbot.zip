# Gemini AI Chatbot - Secure Web App

## 📖 Project Explanation
A modern, secure AI chatbot powered by Google's Gemini AI. Features premium glassmorphism UI, dark mode, voice input/output, conversation history with sidebar, and full authentication (login + registration with persistent users).

Perfect for real-time AI conversations with user management.

## ✨ Features
| Feature | Description |
|---------|-------------|
| **Gemini AI Integration** | Real-time conversations with Gemini 1.5 Flash (fast, intelligent) |
| **Authentication** | Login/Register toggle, JSON user persistence, session protection |
| **Premium UI/UX** | Glassmorphism, animations, responsive design |
| **Dark Mode** | Persistent theme toggle |
| **Voice Chat** | Speech-to-text input + text-to-speech output |
| **Conversation History** | Sidebar with delete/new chat |
| **Quick Replies** | Pre-defined buttons for fast interaction |
| **Protected Routes** | All chat/API behind login |
| **Validation** | Username/password rules, error handling |

## 🛠️ Technologies

### Backend
```
Flask (Python) - Web framework
google.generativeai - Gemini AI SDK
Flask-CORS - Cross-origin requests
JSON - User persistence
Session Auth - Secure login
```

### Frontend
```
HTML5 - Structure
CSS3 - Glassmorphism, animations, responsive, dark mode
Vanilla JS - Voice APIs (SpeechRecognition/SpeechSynthesis), localStorage history, AJAX chat
Jinja2 - Templating
```

### Deployment
```
Single file: `py chatbot_backend.py`
Port: localhost:5000
Auto-reload in debug mode
```

## 🚀 Quick Start
```bash
# Install deps (if needed)
pip install flask flask-cors google-generativeai

# Run
py chatbot_backend.py

# Open
localhost:5000
```

**Login/Register:**
- Demo: `admin` / `admin123`
- Register new accounts (≥3 char username, ≥6 char password)

## 📁 File Structure
```
chatbot_backend.py     # Full app (backend + routes)
templates/
  ├── index.html       # Chat interface
  └── login.html       # Auth forms
static/
  ├── style.css        # UI/animations
  └── script.js        # JS logic (voice/history)
users.json             # User database
```

