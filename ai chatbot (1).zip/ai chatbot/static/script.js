// Enhanced Gemini Chat - Dark Mode, Voice, History Sidebar
class GeminiChat {
  constructor() {
    this.currentChatId = 'chat-1';
    this.chats = JSON.parse(localStorage.getItem('chatHistory')) || {};
    this.isDarkMode = localStorage.getItem('darkMode') === 'true';
    this.isVoiceMode = false;
    this.isListening = false;
    this.recognition = null;
    
    this.initElements();
    this.bindEvents();
    this.loadCurrentChat();
    this.initTheme();
    this.initVoice();
    this.renderHistory();
  }

  initElements() {
    this.sidebar = document.getElementById('sidebar');
    this.historyList = document.getElementById('historyList');
    this.messages = document.getElementById('messages');
    this.input = document.getElementById('messageInput');
    this.sendBtn = document.getElementById('sendButton');
    this.voiceBtn = document.getElementById('voiceBtn');
    this.darkToggle = document.getElementById('darkToggle');
    this.voiceToggle = document.getElementById('voiceToggle');
    this.sidebarToggle = document.getElementById('sidebarToggle');
    this.newChatBtn = document.getElementById('newChatBtn');
  }

  bindEvents() {
    this.input.addEventListener('keypress', (e) => e.key === 'Enter' && this.sendMessage());
    this.sendBtn.addEventListener('click', () => this.sendMessage());
    this.voiceBtn.addEventListener('click', () => this.toggleListening());
    this.darkToggle.addEventListener('click', () => this.toggleDarkMode());
    this.voiceToggle.addEventListener('click', () => this.toggleVoiceMode());
    this.sidebarToggle.addEventListener('click', () => this.toggleSidebar());
    this.newChatBtn.addEventListener('click', () => this.newChat());
    this.historyList.addEventListener('click', (e) => this.handleHistoryClick(e));
  }

  toggleDarkMode() {
    this.isDarkMode = !this.isDarkMode;
    document.documentElement.setAttribute('data-theme', this.isDarkMode ? 'dark' : '');
    localStorage.setItem('darkMode', this.isDarkMode);
    this.darkToggle.textContent = this.isDarkMode ? '☀️' : '🌙';
  }

  toggleVoiceMode() {
    this.isVoiceMode = !this.isVoiceMode;
    this.voiceToggle.style.background = this.isVoiceMode ? 'var(--accent)' : '';
    localStorage.setItem('voiceMode', this.isVoiceMode);
  }

  toggleSidebar() {
    this.sidebar.classList.toggle('open');
  }

  async sendMessage() {
    const text = this.input.value.trim();
    if (!text) return;

    this.addMessage('user', text);
    this.input.value = '';
    this.sendBtn.disabled = true;
    this.showTyping();

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({message: text})
      });
      
      const data = await response.json();
      this.hideTyping();
      
      if (data.error) {
        this.addMessage('assistant', 'Error: ' + data.error);
      } else {
        this.addMessage('assistant', data.response);
        if (this.isVoiceMode) this.speak(data.response);
      }
    } catch (error) {
      this.hideTyping();
      this.addMessage('assistant', 'Connection error.');
    }
    
    this.sendBtn.disabled = false;
    this.scrollToBottom();
    this.saveCurrentChat();
    this.updateHistoryTitle();
  }

  addMessage(role, text) {
    const div = document.createElement('div');
    div.className = `message ${role}`;
    div.innerHTML = `<div class="message-content">${text.replace(/\n/g, '<br>')}</div>`;
    this.messages.appendChild(div);
    this.scrollToBottom();
  }

  showTyping() {
    const typing = document.createElement('div');
    typing.className = 'message assistant typing-container';
    typing.innerHTML = '<div class="typing"><span></span><span></span><span></span></div>';
    this.typingRef = typing;
    this.messages.appendChild(typing);
    this.scrollToBottom();
  }

  hideTyping() {
    if (this.typingRef) {
      this.typingRef.remove();
      this.typingRef = null;
    }
  }

  scrollToBottom() {
    this.messages.scrollTop = this.messages.scrollHeight;
  }

  initVoice() {
    if ('webkitSpeechRecognition' in window) {
      this.recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
      this.recognition.continuous = false;
      this.recognition.interimResults = false;
      this.recognition.lang = 'en-US';
      
      this.recognition.onresult = (e) => {
        this.input.value = e.results[0][0].transcript;
        this.sendMessage();
      };
      
      this.recognition.onerror = () => {
        this.voiceBtn.classList.remove('listening');
        this.addMessage('assistant', 'Voice recognition failed. Use text.');
      };
    }
  }

  toggleListening() {
    if (!this.recognition) {
      this.addMessage('assistant', 'Voice not supported in this browser.');
      return;
    }

    if (this.isListening) {
      this.recognition.stop();
      this.isListening = false;
      this.voiceBtn.classList.remove('listening');
      this.voiceBtn.title = 'Start Voice';
    } else {
      this.recognition.start();
      this.isListening = true;
      this.voiceBtn.classList.add('listening');
      this.voiceBtn.title = 'Listening...';
    }
  }

  speak(text) {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1;
      speechSynthesis.speak(utterance);
    }
  }

  newChat() {
    this.currentChatId = 'chat-' + Date.now();
    this.messages.innerHTML = '';
    this.addMessage('assistant', 'New chat started! Ask me anything.');
    this.saveCurrentChat();
    this.renderHistory();
  }

  loadCurrentChat() {
    const chat = this.chats[this.currentChatId];
    if (chat) {
      chat.messages.forEach(msg => this.addMessage(msg.role, msg.text));
    } else {
      this.addMessage('assistant', '✨ Gemini AI ready! Ask anything.');
    }
  }

  saveCurrentChat() {
    const messages = Array.from(this.messages.querySelectorAll('.message')).map(msg => ({
      role: msg.classList.contains('user') ? 'user' : 'assistant',
      text: msg.querySelector('.message-content').textContent
    }));
    
    this.chats[this.currentChatId] = {
      title: this.generateTitle(messages),
      messages
    };
    
    localStorage.setItem('chatHistory', JSON.stringify(this.chats));
    this.renderHistory();
  }

  generateTitle(messages) {
    if (messages.length === 0) return 'New Chat';
    const firstMsg = messages.find(m => m.role === 'user')?.text || '';
    return firstMsg.substring(0, 30) + (firstMsg.length > 30 ? '...' : '');
  }

  renderHistory() {
    this.historyList.innerHTML = Object.entries(this.chats).map(([id, chat]) => `
      <div class="history-item ${id === this.currentChatId ? 'active' : ''}" data-id="${id}">
        <div>${chat.title}</div>
        <button class="delete-btn" data-id="${id}">🗑️</button>
      </div>
    `).join('');
  }

  handleHistoryClick(e) {
    const item = e.target.closest('.history-item');
    if (!item) return;
    
    if (e.target.classList.contains('delete-btn')) {
      const id = e.target.dataset.id;
      if (confirm('Delete this chat?')) {
        delete this.chats[id];
        localStorage.setItem('chatHistory', JSON.stringify(this.chats));
        this.renderHistory();
        if (id === this.currentChatId) this.newChat();
      }
      return;
    }
    
    const id = item.dataset.id;
    this.switchChat(id);
  }

  switchChat(id) {
    this.currentChatId = id;
    this.messages.innerHTML = '';
    this.loadCurrentChat();
    this.renderHistory();
    this.sidebar.classList.remove('open');
  }

  initTheme() {
    document.documentElement.setAttribute('data-theme', this.isDarkMode ? 'dark' : '');
    this.darkToggle.textContent = this.isDarkMode ? '☀️' : '🌙';
    this.isVoiceMode = localStorage.getItem('voiceMode') === 'true';
    this.voiceToggle.style.background = this.isVoiceMode ? 'var(--accent)' : '';
  }
}

// Init app
new GeminiChat();

