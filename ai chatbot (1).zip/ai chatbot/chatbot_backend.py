from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from flask_cors import CORS
import google.generativeai as genai
import json
import os

app = Flask(__name__)
app.secret_key = 'your-super-secret-key-change-in-production!!'
app.config['TEMPLATES_AUTO_RELOAD'] = True
CORS(app)

# Your Gemini API key - CHANGE THIS
GEMINI_API_KEY = 'AIzaSyD0jHBIJ0U2rwvstD1hOK7_Km5h5PClKIg'

genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-2.5-flash')

USERS_FILE = 'users.json'

def load_users():
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'r') as f:
            data = json.load(f)
            return data.get('users', {})
    return {}

def save_users(users):
    with open(USERS_FILE, 'w') as f:
        json.dump({'users': users}, f)

def login_required(f):
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    mode = request.args.get('mode', 'login')
    error = None
    success = None
    
    if request.method == 'POST':
        action = request.form.get('action')
        username = request.form.get('username').strip()
        password = request.form.get('password')
        
        users = load_users()
        
        if action == 'register':
            if username in users:
                error = 'Username already exists. Login instead?'
            elif len(username) < 3:
                error = 'Username must be at least 3 characters'
            elif len(password) < 6:
                error = 'Password must be at least 6 characters'
            else:
                users[username] = password  # Simple hash in production
                save_users(users)
                session['username'] = username
                return redirect(url_for('index'))
        elif action == 'login':
            if username in users and users[username] == password:
                session['username'] = username
                return redirect(url_for('index'))
            error = 'Invalid username or password'
    
    return render_template('login.html', mode=mode, error=error, success=success)

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
@login_required
def chat():
    try:
        data = request.json
        message = data.get('message', '')
        if not message:
            return jsonify({'error': 'No message provided'}), 400
        
        response = model.generate_content(message)
        return jsonify({'response': response.text})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000, host='0.0.0.0')

